# Hismith Smart Session – Komplett checklista

## Originala krav (PWA → native)
- [x] Anslut Hismith-maskin + Lube Launcher via Bluetooth
- [x] Min/max tid, intern slumpad sessionstid
- [x] Auto-Lube av/på
- [x] Mänsklig algoritm: rytm, max burst, deep hold, tease
- [x] Mjuka accelerationer (easing)
- [x] Bakgrundspump från launcher
- [x] Automatisk final (stort sprut + nedvarvning + stopp)
- [x] Nödstopp alltid tillgängligt
- [x] Extra Sprut + SUPER SPRUT
- [x] Mörkt, pekvänligt UI

## Utökade krav
- [x] Native app med bakgrundskörning (Foreground Service)
- [x] Webbläsare med adblock + fullscreen-video
- [x] Overlay STOPP + SUPER SPRUT i webbläsarläge
- [x] Växla Kontroll / Webbläsare
- [x] Kör utan Lube Launcher
- [x] Thrusting Pocket Masturbator samtidigt
- [x] Flera maskiner synkade (hals, anal, extra, pocket)
- [x] Automatisk BLE-återanslutning
- [x] Batteriundantag
- [x] **Smart slaglängd** (elektronisk) – oförutsägbar & mänsklig

## Smart slaglängd
Aktivera kryssrutan **Smart slaglängd** om din maskin stödjer elektronisk stroke
(t.ex. vissa Pro/Servok). Appen varierar då start/stopp av slaglängden per fas:
- Rytm: medel–lång, levande
- Burst: kortare fokus vid maxfart
- Deep Hold: djupt parkerat
- Tease: grunda → djupa → långa slag
- Final: långsamma djupa slag

Maskiner med enbart mekanisk slaglängd påverkas inte (kommandona ignoreras).

## Bygga
Android Studio → Open → mappen hismith-native → Build APK.
