package com.hismith.session

import android.app.*
import android.bluetooth.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.util.*
import java.util.concurrent.ConcurrentHashMap

data class ManagedDevice(
    val address: String,
    val name: String,
    var role: DeviceRole,
    var gatt: BluetoothGatt? = null,
    var tx: BluetoothGattCharacteristic? = null,
    @Volatile var connected: Boolean = false
)

class SessionService : Service() {

    companion object {
        const val CHANNEL_ID = "hismith_session"
        const val NOTIF_ID = 42
        const val ACTION_STOP = "com.hismith.session.STOP"
        const val ACTION_MEGA_SPRAY = "com.hismith.session.MEGA_SPRAY"
        const val ACTION_SHORT_SPRAY = "com.hismith.session.SHORT_SPRAY"
        const val ACTION_START_SESSION = "com.hismith.session.START"
        const val ACTION_END_SESSION = "com.hismith.session.END"
        const val BROADCAST_STATUS = "com.hismith.session.STATUS"
        const val EXTRA_SPEED = "speed"
        const val EXTRA_PHASE = "phase"
        const val EXTRA_ELAPSED = "elapsed"
        const val EXTRA_PROGRESS = "progress"
        const val EXTRA_RUNNING = "running"
        const val EXTRA_DEVICE_SUMMARY = "devices"
    }

    private val binder = LocalBinder()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val devices = ConcurrentHashMap<String, ManagedDevice>()
    private lateinit var engine: SessionEngine
    private var tickJob: Job? = null
    private var reconnectJob: Job? = null

    inner class LocalBinder : Binder() {
        fun getService(): SessionService = this@SessionService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        engine = SessionEngine(
            onSpeed = { speed -> applySpeedToAllMachines(speed) },
            onStroke = { start, stop -> applyStrokeToMachines(start, stop) },
            onPhase = { phase -> broadcastStatus(phase = phase) },
            onSpray = { seconds -> scope.launch { doSprayAll(seconds) } },
            onFinished = { stopSessionInternal() }
        )
        reconnectJob = scope.launch {
            while (isActive) {
                delay(4000)
                devices.values.filter { !it.connected && it.gatt != null }.forEach { dev ->
                    try { dev.gatt?.connect() } catch (_: Exception) {}
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> emergencyStop()
            ACTION_MEGA_SPRAY -> scope.launch { doSprayAll(9.0) }
            ACTION_SHORT_SPRAY -> scope.launch { doSprayAll(0.5) }
            ACTION_END_SESSION -> stopSessionInternal()
            ACTION_START_SESSION -> {
                startSession(
                    intent.getIntExtra("min", 20),
                    intent.getIntExtra("max", 45),
                    intent.getBooleanExtra("autoLube", true),
                    intent.getBooleanExtra("smartStroke", false)
                )
            }
        }
        return START_STICKY
    }

    fun startForegroundProtected() {
        val notif = buildNotification("Redo", deviceSummary())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    fun connectDevice(device: BluetoothDevice, role: DeviceRole) {
        devices[device.address]?.gatt?.close()
        val managed = ManagedDevice(device.address, device.name ?: role.label, role)
        devices[device.address] = managed
        val callback = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
                val dev = devices[gatt.device.address] ?: return
                if (newState == BluetoothProfile.STATE_CONNECTED) gatt.discoverServices()
                else {
                    dev.connected = false
                    dev.tx = null
                    broadcastStatus()
                }
            }
            override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                val dev = devices[gatt.device.address] ?: return
                val service = gatt.getService(UUID.fromString(HismithProtocol.SERVICE_UUID))
                val char = service?.getCharacteristic(UUID.fromString(HismithProtocol.TX_UUID))
                dev.tx = char
                dev.connected = char != null
                if (dev.connected && dev.role != DeviceRole.LUBE_LAUNCHER) {
                    writeRaw(gatt, char, HismithProtocol.powerOn())
                    writeRaw(gatt, char, HismithProtocol.manualMode())
                    writeRaw(gatt, char, HismithProtocol.setSpeedAA(0))
                    writeRaw(gatt, char, HismithProtocol.setSpeedFF(0))
                }
                broadcastStatus()
                updateNotification("Ansluten", deviceSummary())
            }
        }
        managed.gatt = device.connectGatt(this, false, callback, BluetoothDevice.TRANSPORT_LE)
    }

    fun getDevices(): List<ManagedDevice> = devices.values.toList()
    fun hasAnyMachine(): Boolean =
        devices.values.any { it.connected && it.role != DeviceRole.LUBE_LAUNCHER }

    private fun applySpeedToAllMachines(percent: Int) {
        val p = percent.coerceIn(0, 100)
        devices.values.forEach { dev ->
            if (!dev.connected || dev.tx == null) return@forEach
            when (dev.role) {
                DeviceRole.LUBE_LAUNCHER -> {}
                DeviceRole.POCKET_STROKER -> {
                    writeRaw(dev.gatt, dev.tx, HismithProtocol.setSpeedAA(p))
                    writeRaw(dev.gatt, dev.tx, HismithProtocol.setSpeedFF(p))
                    if (p > 5) writeRaw(dev.gatt, dev.tx, HismithProtocol.makeAA(0x06, (p / 2).coerceIn(0, 100)))
                    else writeRaw(dev.gatt, dev.tx, HismithProtocol.makeAA(0x06, 0xF0))
                }
                else -> {
                    writeRaw(dev.gatt, dev.tx, HismithProtocol.setSpeedAA(p))
                    writeRaw(dev.gatt, dev.tx, HismithProtocol.setSpeedFF(p))
                }
            }
        }
        broadcastStatus(speed = p)
    }

    private fun applyStrokeToMachines(startPercent: Int, stopPercent: Int) {
        val start = startPercent.coerceIn(0, 100)
        val stop = stopPercent.coerceIn(start + 10, 100)
        devices.values.forEach { dev ->
            if (!dev.connected || dev.tx == null) return@forEach
            if (dev.role == DeviceRole.LUBE_LAUNCHER || dev.role == DeviceRole.POCKET_STROKER) return@forEach
            writeRaw(dev.gatt, dev.tx, HismithProtocol.setStrokeStart(start))
            writeRaw(dev.gatt, dev.tx, HismithProtocol.setStrokeStop(stop))
            writeRaw(dev.gatt, dev.tx, HismithProtocol.setSmoothness(7))
            writeRaw(dev.gatt, dev.tx, HismithProtocol.servoMinLength(start))
            writeRaw(dev.gatt, dev.tx, HismithProtocol.servoMaxLength(stop))
            writeRaw(dev.gatt, dev.tx, HismithProtocol.servoSmoothness(7))
        }
    }

    private fun writeRaw(gatt: BluetoothGatt?, char: BluetoothGattCharacteristic?, data: ByteArray) {
        if (gatt == null || char == null) return
        try {
            char.value = data
            char.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            gatt.writeCharacteristic(char)
        } catch (_: Exception) {}
    }

    private suspend fun doSprayAll(seconds: Double) {
        val lubes = devices.values.filter { it.role == DeviceRole.LUBE_LAUNCHER && it.connected }
        if (lubes.isEmpty()) return
        val end = System.currentTimeMillis() + (seconds * 1000).toLong()
        while (System.currentTimeMillis() < end) {
            lubes.forEach { writeRaw(it.gatt, it.tx, HismithProtocol.LUBE_SQUIRT_SHORT) }
            delay(280)
        }
    }

    fun startSession(minMinutes: Int, maxMinutes: Int, autoLube: Boolean, smartStroke: Boolean = false) {
        if (!hasAnyMachine()) return
        engine.start(minMinutes, maxMinutes, autoLube, smartStroke)
        updateNotification("Session igång", deviceSummary())
        tickJob?.cancel()
        tickJob = scope.launch {
            while (isActive && engine.isRunning) {
                engine.tick()
                broadcastStatus(elapsed = engine.elapsedSeconds(), progress = engine.progressPercent())
                delay(80)
            }
        }
        broadcastStatus(running = true)
    }

    private fun stopSessionInternal() {
        engine.stop()
        applySpeedToAllMachines(0)
        devices.values.forEach { dev ->
            if (dev.role != DeviceRole.LUBE_LAUNCHER) {
                writeRaw(dev.gatt, dev.tx, HismithProtocol.powerOff())
                writeRaw(dev.gatt, dev.tx, HismithProtocol.stopFF())
            }
        }
        tickJob?.cancel()
        updateNotification("Session stoppad", deviceSummary())
        broadcastStatus(running = false, phase = "Stoppad", speed = 0)
    }

    fun emergencyStop() {
        engine.emergencyStop()
        applySpeedToAllMachines(0)
        devices.values.forEach { dev ->
            writeRaw(dev.gatt, dev.tx, HismithProtocol.powerOff())
            writeRaw(dev.gatt, dev.tx, HismithProtocol.stopFF())
            writeRaw(dev.gatt, dev.tx, HismithProtocol.setSpeedAA(0))
        }
        tickJob?.cancel()
        updateNotification("NÖDSTOPP", "Allt stoppat")
        broadcastStatus(running = false, phase = "NÖDSTOPP", speed = 0)
    }

    private fun deviceSummary(): String {
        val parts = devices.values.filter { it.connected }.map { it.role.label }
        return if (parts.isEmpty()) "Inga enheter" else parts.joinToString(", ")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Hismith Session", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        val stopPi = PendingIntent.getService(this, 0, Intent(this, SessionService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val openPi = PendingIntent.getActivity(this, 0, packageManager.getLaunchIntentForPackage(packageName), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title).setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_delete, "STOPP", stopPi)
            .setOngoing(true).setOnlyAlertOnce(true).setSilent(true).build()
    }

    private fun updateNotification(title: String, text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(title, text))
    }

    private fun broadcastStatus(speed: Int? = null, phase: String? = null, elapsed: Long? = null, progress: Float? = null, running: Boolean? = null) {
        val summary = devices.values.joinToString(";") { "${it.role.name}:${if (it.connected) 1 else 0}:${it.name}" }
        sendBroadcast(Intent(BROADCAST_STATUS).apply {
            setPackage(packageName)
            putExtra(EXTRA_RUNNING, running ?: engine.isRunning)
            putExtra(EXTRA_DEVICE_SUMMARY, summary)
            speed?.let { putExtra(EXTRA_SPEED, it) }
            phase?.let { putExtra(EXTRA_PHASE, it) }
            elapsed?.let { putExtra(EXTRA_ELAPSED, it) }
            progress?.let { putExtra(EXTRA_PROGRESS, it) }
        })
    }

    override fun onDestroy() {
        tickJob?.cancel(); reconnectJob?.cancel(); scope.cancel()
        devices.values.forEach { it.gatt?.close() }
        devices.clear()
        super.onDestroy()
    }
}
